#!/bin/bash

#unmount
Pass=$(zenity --password --title="Administrator Password")   
echo "$Pass" | sudo -S umount /media/H_Drive

#remove bookmark
egrep -v file:///media/H_Drive $HOME/.gtk-bookmarks > $HOME/.gtk-tmp
cp $HOME/.gtk-tmp $HOME/.gtk-bookmarks
rm .gtk-tmp

exit 0
