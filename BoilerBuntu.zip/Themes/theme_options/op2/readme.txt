This is the second options of the boot screen.

you need to be signed into rood to beable to modify the plymouth folder and the files inside that folder.

copy a backup of plymouth folder to desktop before replacing with this version.

plymouth folder is located in /lib/plymouth

This theme has a black background and white BoilerBuntu text with a complete white logo. 

i can play around with the colors all day so if you have any suggestions for what colors you want to see just tell me. i cant seem to choose which colors i like best.


