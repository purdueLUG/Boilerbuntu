#!/bin/bash

#make copy of fstab in case things go wrong
#mkdir $HOME/Credentials 

#get sudo password
Pass=$(zenity --password --title="Administrator Password")   
echo "$Pass" | sudo -S mkdir /media/H_Drive
cp /etc/fstab $HOME/Credentials/.fstab_tmp 

#need to install smbfs to work
sudo apt-get install smbfs

if (( $? != 0 ))
then
    echo "Error: could not install smbfs"
    exit 1
fi

sudo update-rc.d -f umountnfs.sh remove
sudo update-rc.d umountnfs.sh stop 15 0 6 .

#get credentials
Cred=$(zenity --password --username --title="Enter Purdue Account Info")

User=$(echo $Cred|cut -d'|' -f1)

echo "username=$(echo $Cred|cut -d'|' -f1)" > ~/Credentials/Cred_file
echo "password=$(echo $Cred|cut -d'|' -f2)" >> ~/Credentials/Cred_file

#add line to fstab
sudo sed -i "$ a //rosetta.ics.purdue.edu/$User /media/H_Drive cifs credentials=$HOME/Credentials/Cred_file 0 0" /etc/fstab

#mount filesystem
sudo mount -a

#add bookmark
echo "file:///media/H_Drive" >> $HOME/.gtk-bookmarks
 
exit 0
